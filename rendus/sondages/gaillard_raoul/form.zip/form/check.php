<?php
	//Verification des infos du formulaire
	define('SALT', '8Qqudè!è§S76D');
	define('CAPT_SECRET', '6LeYKwMTAAAAAHZvleNwRkdPQCYqvu9a24doSPEh');
	$captcha = $_POST['g-recaptcha-response'];
	$response= file_get_contents("https://www.google.com/recaptcha/api/siteverify?secret=".CAPT_SECRET."&response=".$captcha."&remoteip=".$_SERVER['REMOTE_ADDR']);


	if (!preg_match('/[a-zA-Z]{15}/',$_POST['name']))
	{
		$error = $error + 'Votre prénom doit contenir entre 4 et 15 caractères sans chiffres.';
	}
	else if (!preg_match('/^(0?\d|[12]\d|3[01])-(0?\d|1[012])-((?:19|20)\d{2})$/',$_POST['mail']) === 0) {
		$error = $error + 'E-mail invalide.';
	}
	else if (!preg_match('/male|female/',$_POST['gender'])) {
		$error = $error + 'Veuillez sélectionner un genre.';
	}
	else if (!preg_match('/^0[1-68][0-9]{8}$/',$_POST['phone'])) {
		$error = $error + 'Téléphone non valide.';
	}
	else if (!preg_match('/^(((0[1-9]|[12]\d|3[01])\/(0[13578]|1[02])\/((19|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)\/(0[13456789]|1[012])\/((19|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])\/02\/((19|[2-9]\d)\d{2}))|(29\/02\/((1[6-9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|((16|[2468][048]|[3579][26])00))))$/',$_POST['birth'])) {
		$error = $error + 'Date de naissance invalide.';
	}
	else if ($response.success === false) {
		$error = $error + 'Captcha invalide.';
	}
	else if (!preg_match('/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])[\da-zA-Z]{8,20}$/', $_POST['mdp'])) {
		$error = $error + 'Votre mot de passe doit contenir entre 8 et 20 caractères dont majuscule, minuscule et chiffres.';
	}
	else if ($_POST['mdp'] !== $_POST['mdp-repeat']) {
		$error = $error + 'Veuillez rentrer le même mot de passe.';
	}
	else if ($_POST['condition'] !== 'agree' ) {
		$error = $error + 'Veuillez accepter les conditions dutilisation';
	}
	else {
		$prepare = $pdo->prepare('INSERT INTO users (mail,name,birth,phone,mdp) VALUES (:mail,:name,:birth,:phone,:mdp)');
		$prepare->bindValue(':mail',$_POST['mail']);
		$prepare->bindValue(':name',$_POST['name']);
		$prepare->bindValue(':birth',$_POST['birth']);
		$prepare->bindValue(':phone',$_POST['phone']);
		$prepare->bindValue(':mdp',hash('sha256',$_POST['mdp'].SALT));
		$exec = $prepare->execute();
	}
