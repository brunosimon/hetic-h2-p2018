<?php
	require 'config.php';

	if (!empty($_POST)) {
		echo '<pre>';
		print_r($_POST);
		echo '</pre>';
	}
?>

<!DOCTYPE html>
<html>

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Exo PHP | Raoul Gaillard </title>
	<link rel="stylesheet" href="css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>

<body>
	
	<div class="container">
		<div class="row">
			<div class="col-md-4"></div>
			<div class="col-md-4">
				<h2 class="page-header">Se connecter</h2>
				<form action="#" method="post">
				<div class="form-group">
					<label for="user_mail">Email</label>
					<input type="email" name="user_mail" placeholder="Email" class="form-control">
				</div>
				<div class="form-group">
					<label for="user_password">Mot de passe</label>
					<input type="password" name="user_password" placeholder="Mot de passe" class="form-control">
				</div class="form-group">
				<div class="form-group">
					<button class="button btn btn-default" type="submit">Valider</button>
				</div>
				<div class="form-group">
					<label>
						<input type="checkbox" name="form_checkbox">Resté connecté
					</label>
				</div>
				<div class="form-group">
					<a href="subscribe.php" class="btn btn-default" title="">S'inscrire</a>
					<div href="" class="link">J'ai oublié mon mot de passe</div>
				</div>
				</form>

			</div>
			<div class="col-md-4"></div>
		</div>
		</div>
	</div>

</body>

</html>