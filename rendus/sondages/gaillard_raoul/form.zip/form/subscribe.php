<?php
	require 'config.php';
	require 'check.php';

	if (!empty($_POST)) {
		echo '<pre>';
		print_r($_POST);
		echo '</pre>';
	}
?>

<!DOCTYPE html>
<html>

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Exo PHP | Inscription </title>
	<link rel="stylesheet" href="css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>

<body>
	
	<div class="container">
		<div class="row">
			<div class="col-md-4"></div>
			<div class="col-md-4">
				<h2 class="page-header">S'inscrire</h2>
				<form action="#" method="post">
					<div>
						<div class="form-group">
							<label for="mail">Email</label>
							<input type="email" name="mail" placeholder="Email" class="form-control">
						</div>
						
						<div class="form-group">
							<label for="name">Prénom</label>
							<input type="text" name="name"placeholder="Votre prénom" class="form-control">
						</div>
						<div class="form-group">
							<label for="gender">Sexe</label>
							<br>
							<div class="radio-inline">
								<label for="gender">
									<input type="radio" name="gender" value="male" placeholder="Homme">
									Homme
								</label>
								
							</div>
							<div class="radio-inline">
								<label for="gender">
									<input type="radio" name="gender" value="female" placeholder="Femme">
									Femme
								</label>
							</div>
						</div>

						<div class="form-group">
							<label for="birth">Date de naissance</label>
							<input type="date" name="birth" class="form-control">
						</div>

						<div class="form-group">
							<label for="phone">Téléphone (facultatif)</label>
							<input type="tel" name="phone" placeholder="Téléphone" class="form-control">
						</div>

						<div class="form-group">
							<label for="mdp">Mot de passe</label>
							<div class="panel panel-default">
								<div class="panel-body bg-info">
									Votre mot de passe doit faire entre 6 et 11 caractères incluant des chiffres et des lettres
								</div>
							</div>
							<input type="password" name="mdp" placeholder="Mot de passe" class="form-control">
							<br>
							<input type="password" name="mdp-repeat" placeholder="Répétez mot de passe" class="form-control">
						</div>

						<div class="form-group">
							<div class="panel panel-default">
  								<div class="panel-heading">
  								  <h3 class="panel-title">Condition d'utilisation</h3>
  								</div>
  								<div class="panel-body">
  								 Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
								tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
								quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
								consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
								cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
								proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
  								</div>
							</div>
							<div class="checkbox">
								<label for="condition">
								<input type="checkbox" name="condition" value="agree">
								J'accepte les conditions d'utilisation
								</label>
							</div>
						</div>
						
						<div class="form-group">
							<div class="g-recaptcha" data-sitekey="6LeYKwMTAAAAAMEa7LSzOvPHxT3KiSCKxUhSq3qh"></div>
						</div>
						
						<div class="form-group">
							<button type="submit" class="btn btn-default">S'inscrire</button>
						</div>
					</div>
				</form>

			</div>
			<div class="col-md-4"></div>
		</div>
	</div>

	<script src='https://www.google.com/recaptcha/api.js'></script>

</body>

</html>