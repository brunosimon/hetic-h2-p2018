<?php

	require 'inc/config.php';

	die('ok');